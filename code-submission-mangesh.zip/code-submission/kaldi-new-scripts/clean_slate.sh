#!/usr/bin/bash

rm -rf data
rm -rf exp
rm -rf mfcc
