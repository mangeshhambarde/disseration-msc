Dihard dev only x-vector model.
