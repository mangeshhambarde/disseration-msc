Recipe to train PLDA model based on i-vector + x-vector using v3 and v4 outputs.
