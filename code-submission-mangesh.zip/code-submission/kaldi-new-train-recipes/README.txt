There are 5 new recipes that were created for this dissertation:

cvector
dev-only-ivec
dev-only-xvec
vox1-dev-ivec
vox1-dev-xvec

Please check the README.txt in each directory to see what the recipe is for.
Only the important files for evaluation are included.
If full recipes are needed, import the patch "kaldi-commits.patch" on a fresh kaldi repo.
