Voxceleb I full + Dihard dev i-vector model.
