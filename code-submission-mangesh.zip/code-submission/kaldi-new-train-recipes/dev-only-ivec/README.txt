Dihard dev only i-vector model.
