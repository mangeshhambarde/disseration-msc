All the code changes made for the dissertation can be found as .patch files.

baseline-commits.patch    apply on dihard baseline repo
kaldi-commits.patch       apply on kaldi repo
dscore-commits.patch      apply on dscore repo

baseline repo            https://github.com/iiscleap/DIHARD_2019_baseline_alltracks
kaldi repo               https://github.com/kaldi-asr/kaldi
dscore repo              https://github.com/nryant/dscore

If you want to see the files modified/created during the dissertation directly, see the following directories.

baseline-modified-scripts      modified scripts from baseline
kaldi-new-cpp                  new kaldi c++ programs
kaldi-new-scripts              new scripts for kaldi
kaldi-new-train-recipes        new training recipes for kaldi

